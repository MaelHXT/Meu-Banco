 import { getState, setState, transaction } from '../src/core/store.js';
import { now } from '../src/core/time.js';
import { processCompanyDeposits, processCreditCharges, processLoanCharges } from '../src/features/accounts.js';
import { processInvestmentDividends } from '../src/features/investments.js';
import { updateCryptoPrice } from '../src/features/crypto-market.js';
import { getLeaderTabId, electionLeader } from '../src/core/sync.js';
import { initStorage, loadState } from '../src/core/db.js';

let isRunning = false;

async function runLoop() {
    await electionLeader(); // Reeleição periódica
    const state = getState();
    const currentTime = now();
    let hasChanged = false;

    if (state.timers.engineLeader.tabId !== getLeaderTabId()) {
        console.log('Worker não é a aba líder. Pausando...');
        return;
    }

    if (currentTime - state.timers.lastMinuteTick >= 60000) {
        transaction((draft) => {
            processCompanyDeposits(draft);
            processCreditCharges(draft);
            processLoanCharges(draft);
            draft.timers.lastMinuteTick = currentTime;
        });
        hasChanged = true;
    }

    if (currentTime - state.timers.lastDividendTick >= 10000) {
        transaction((draft) => {
            processInvestmentDividends(draft);
            draft.timers.lastDividendTick = currentTime;
        });
        hasChanged = true;
    }

    if (currentTime - state.timers.lastCryptoTick >= 5000) {
        transaction((draft) => {
            updateCryptoPrice(draft);
            draft.timers.lastCryptoTick = currentTime;
        });
        hasChanged = true;
    }
    
    if (hasChanged) {
        postMessage({ type: 'STATE_UPDATE', state: getState() });
    }

    setTimeout(runLoop, 1000); // Roda a cada segundo
}

onmessage = async (event) => {
    if (event.data.type === 'START_ENGINE' && !isRunning) {
        isRunning = true;
        await initStorage();
        await loadState();
        runLoop();
    }
};
