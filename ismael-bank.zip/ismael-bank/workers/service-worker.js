 const CACHE_NAME = 'ismael-bank-cache-v1';
const urlsToCache = [
    '/',
    '/index.html',
    '/assets/styles.css',
    '/assets/icons.svg',
    '/data/seed.json',
    '/src/app.js',
    '/src/ui/router.js',
    '/src/ui/components.js',
    '/src/ui/formatters.js',
    '/src/ui/screens/login.js',
    '/src/ui/screens/adminDashboard.js',
    '/src/ui/screens/clientDashboard.js',
    '/src/core/crypto.js',
    '/src/core/time.js',
    '/src/core/validators.js',
    '/src/core/schema.js',
    '/src/core/db.js',
    '/src/core/store.js',
    '/src/core/sync.js',
    '/src/core/engine.js',
    '/src/features/auth.js',
    '/src/features/admin.js',
    '/src/features/accounts.js',
    '/src/features/credit.js',
    '/src/features/loans.js',
    '/src/features/investments.js',
    '/src/features/crypto-market.js',
    '/src/features/pix.js',
    '/src/features/history.js',
    '/src/features/notifications.js',
    '/src/charts/mini-canvas.js',
    '/workers/engine-worker.js'
];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            console.log('Cache preenchido');
            return cache.addAll(urlsToCache);
        }).catch(err => {
            console.error('Falha ao adicionar ao cache:', err);
        })
    );
});

self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request).then(response => {
            if (response) {
                return response;
            }
            return fetch(event.request);
        })
    );
});
