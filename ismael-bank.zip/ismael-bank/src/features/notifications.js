 const toastsContainer = document.getElementById('toastsContainer');

export function initNotifications() {
    if (!toastsContainer) {
        console.error('Elemento toastsContainer não encontrado!');
    }
}

export function showToast(message, type = 'info') {
    if (!toastsContainer) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;

    toastsContainer.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-10px)';
        setTimeout(() => toast.remove(), 500);
    }, 5000);
}
