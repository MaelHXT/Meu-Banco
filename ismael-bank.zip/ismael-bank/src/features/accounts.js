 import { getState, transaction } from '../core/store.js';
import { showToast } from './notifications.js';
import { now } from '../core/time.js';
import { addHistoryEntry } from './history.js';
import { formatMoney } from '../ui/formatters.js';

const ADMIN_USERNAME = 'cs304352';

export function processCompanyDeposits(state) {
    const adminUser = state.users[ADMIN_USERNAME];
    if (!adminUser) return;
    
    const totalDeposit = state.companies.length * 1000;
    
    adminUser.balances.checking += totalDeposit;
    
    addHistoryEntry(state, ADMIN_USERNAME, {
        ts: now(),
        type: 'company-deposits',
        amount: totalDeposit,
        before: adminUser.balances.checking - totalDeposit,
        after: adminUser.balances.checking,
        details: 'Depósitos automáticos das 30 empresas.'
    });
    showToast(`ADM recebeu R$ ${totalDeposit} de depósitos das empresas.`, 'success');
}

export function processCreditCharges(state) {
    const currentTime = now();
    const adminUser = state.users[ADMIN_USERNAME];
    
    Object.values(state.users).forEach(user => {
        user.creditInvoices.forEach(invoice => {
            if (invoice.remainingInstallments > 0 && currentTime - invoice.lastChargeAt >= 60000) {
                const chargeAmount = invoice.installmentValue;
                
                if (user.balances.checking >= chargeAmount) {
                    user.balances.checking -= chargeAmount;
                    user.balances.creditUsed -= chargeAmount;
                    invoice.remainingInstallments -= 1;
                    invoice.lastChargeAt = currentTime;
                    
                    if (adminUser) {
                        adminUser.balances.checking += chargeAmount;
                        addHistoryEntry(state, ADMIN_USERNAME, {
                            ts: currentTime,
                            type: 'credit-receipt',
                            amount: chargeAmount,
                            before: adminUser.balances.checking - chargeAmount,
                            after: adminUser.balances.checking,
                            details: `Recebimento de parcela de fatura de ${user.username}`
                        });
                    }

                    addHistoryEntry(state, user.username, {
                        ts: currentTime,
                        type: 'credit-payment',
                        amount: -chargeAmount,
                        before: user.balances.checking + chargeAmount,
                        after: user.balances.checking,
                        details: `Pagamento de parcela de fatura (${invoice.id})`
                    });

                    showToast(`Parcela da fatura (${invoice.id}) de ${formatMoney(chargeAmount)} paga.`, 'success');
                } else {
                    showToast(`Atenção: Saldo insuficiente para pagar parcela da fatura (${invoice.id}).`, 'warning');
                }
            }
        });
        user.creditInvoices = user.creditInvoices.filter(inv => inv.remainingInstallments > 0);
    });
}

export function processLoanCharges(state) {
    const currentTime = now();
    const adminUser = state.users[ADMIN_USERNAME];
    
    Object.values(state.users).forEach(user => {
        user.loans.forEach(loan => {
            if (loan.status === 'active' && loan.remaining > 0 && currentTime - loan.lastChargeAt >= 60000) {
                const chargeAmount = loan.installmentValue;
                
                if (user.balances.checking >= chargeAmount) {
                    user.balances.checking -= chargeAmount;
                    loan.remaining -= chargeAmount;
                    loan.lastChargeAt = currentTime;
                    
                    if (adminUser) {
                        adminUser.balances.checking += chargeAmount;
                        addHistoryEntry(state, ADMIN_USERNAME, {
                            ts: currentTime,
                            type: 'loan-receipt',
                            amount: chargeAmount,
                            before: adminUser.balances.checking - chargeAmount,
                            after: adminUser.balances.checking,
                            details: `Recebimento de parcela de empréstimo de ${user.username}`
                        });
                    }
                    
                    addHistoryEntry(state, user.username, {
                        ts: currentTime,
                        type: 'loan-payment',
                        amount: -chargeAmount,
                        before: user.balances.checking + chargeAmount,
                        after: user.balances.checking,
                        details: `Pagamento de parcela de empréstimo (${loan.id})`
                    });
                    
                    showToast(`Parcela do empréstimo (${loan.id}) de ${formatMoney(chargeAmount)} paga.`, 'success');

                } else {
                    loan.status = 'pending';
                    showToast(`Atenção: Saldo insuficiente para pagar parcela do empréstimo (${loan.id}). Empréstimo pendente.`, 'warning');
                }
            }
        });
        user.loans = user.loans.filter(loan => loan.remaining > 0);
    });
}

export function deposit(amount, username) {
    transaction((draft) => {
        const user = draft.users[username];
        if (!user) {
            showToast('Usuário não encontrado.', 'error');
            return;
        }
        if (amount <= 0) {
            showToast('O valor do depósito deve ser positivo.', 'error');
            return;
        }

        user.balances.checking += amount;
        addHistoryEntry(draft, username, {
            ts: now(),
            type: 'deposit',
            amount,
            before: user.balances.checking - amount,
            after: user.balances.checking,
            details: 'Depósito em conta.'
        });
        showToast(`Depósito de ${formatMoney(amount)} realizado com sucesso!`, 'success');
    });
}

export function withdraw(amount, username) {
    transaction((draft) => {
        const user = draft.users[username];
        const admin = draft.users[draft.adminUsername];
        if (!user) {
            showToast('Usuário não encontrado.', 'error');
            return;
        }
        const fee = amount * 0.01;
        const totalAmount = amount + fee;
        
        if (user.balances.checking < totalAmount) {
            showToast('Saldo insuficiente para o saque e taxa.', 'error');
            return;
        }

        user.balances.checking -= totalAmount;
        admin.balances.checking += fee;
        
        addHistoryEntry(draft, username, {
            ts: now(),
            type: 'withdraw',
            amount: -amount,
            before: user.balances.checking + totalAmount,
            after: user.balances.checking,
            details: `Saque de ${formatMoney(amount)}. Taxa de ${formatMoney(fee)}.`
        });
        
        addHistoryEntry(draft, ADMIN_USERNAME, {
            ts: now(),
            type: 'fee-receipt',
            amount: fee,
            before: admin.balances.checking - fee,
            after: admin.balances.checking,
            details: `Recebimento de taxa de saque de ${user.username}.`
        });

        showToast(`Saque de ${formatMoney(amount)} realizado. Taxa: ${formatMoney(fee)}.`, 'success');
    });
}
