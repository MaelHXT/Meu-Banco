 import { getState, transaction } from '../core/store.js';
import { showToast } from './notifications.js';
import { now } from '../core/time.js';
import { addHistoryEntry } from './history.js';
import { formatMoney } from '../ui/formatters.js';

const ADMIN_USERNAME = 'cs304352';

export function updateCryptoPrice(state) {
    const price = state.cryptoMarket.price;
    const change = (Math.random() - 0.5) * price * 0.01; // ±0.5%
    const newPrice = Math.max(0.01, price + change);

    state.cryptoMarket.price = newPrice;
    state.cryptoMarket.lastUpdate = now();
}

export function buyCrypto(amount) {
    const state = getState();
    const currentUser = state.users[state.currentUser];
    const admin = state.users[ADMIN_USERNAME];

    if (!currentUser) return;
    
    const price = state.cryptoMarket.price;
    const cost = amount * price;
    const fee = cost * 0.01;
    const totalCost = cost + fee;

    if (currentUser.balances.checking < totalCost) {
        showToast('Saldo em conta insuficiente para a compra.', 'error');
        return;
    }

    transaction((draft) => {
        const draftUser = draft.users[draft.currentUser];
        const draftAdmin = draft.users[ADMIN_USERNAME];
        
        draftUser.balances.checking -= totalCost;
        draftUser.crypto.balance += amount;
        draftAdmin.balances.checking += fee;

        addHistoryEntry(draft, draft.currentUser, {
            ts: now(),
            type: 'crypto-buy',
            amount: -totalCost,
            before: draftUser.balances.checking + totalCost,
            after: draftUser.balances.checking,
            details: `Compra de ${amount.toFixed(4)} ISB por ${formatMoney(cost)}. Taxa: ${formatMoney(fee)}.`
        });

        addHistoryEntry(draft, ADMIN_USERNAME, {
            ts: now(),
            type: 'crypto-fee',
            amount: fee,
            before: draftAdmin.balances.checking - fee,
            after: draftAdmin.balances.checking,
            details: `Recebimento de taxa de compra de ISB de ${draftUser.username}.`
        });
        showToast(`Compra de ${amount.toFixed(4)} ISB realizada com sucesso!`, 'success');
    });
}

export function sellCrypto(amount) {
    const state = getState();
    const currentUser = state.users[state.currentUser];
    const admin = state.users[ADMIN_USERNAME];

    if (!currentUser || currentUser.crypto.balance < amount) {
        showToast('Saldo em ISB insuficiente para a venda.', 'error');
        return;
    }
    
    const price = state.cryptoMarket.price;
    const value = amount * price;
    const fee = value * 0.01;
    const totalValue = value - fee;

    transaction((draft) => {
        const draftUser = draft.users[draft.currentUser];
        const draftAdmin = draft.users[ADMIN_USERNAME];
        
        draftUser.crypto.balance -= amount;
        draftUser.balances.checking += totalValue;
        draftAdmin.balances.checking += fee;

        addHistoryEntry(draft, draft.currentUser, {
            ts: now(),
            type: 'crypto-sell',
            amount: totalValue,
            before: draftUser.balances.checking - totalValue,
            after: draftUser.balances.checking,
            details: `Venda de ${amount.toFixed(4)} ISB por ${formatMoney(value)}. Taxa: ${formatMoney(fee)}.`
        });
        
        addHistoryEntry(draft, ADMIN_USERNAME, {
            ts: now(),
            type: 'crypto-fee',
            amount: fee,
            before: draftAdmin.balances.checking - fee,
            after: draftAdmin.balances.checking,
            details: `Recebimento de taxa de venda de ISB de ${draftUser.username}.`
        });
        showToast(`Venda de ${amount.toFixed(4)} ISB realizada.`, 'success');
    });
}
