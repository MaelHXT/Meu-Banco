 import { getState, transaction } from '../core/store.js';
import { showToast } from './notifications.js';
import { now } from '../core/time.js';
import { addHistoryEntry } from './history.js';
import { uid } from '../core/crypto.js';
import { formatMoney } from '../ui/formatters.js';

const LOAN_INTEREST_RATE = 0.05; // 5% de juros sobre o principal

export function requestLoan(amount) {
    const state = getState();
    const currentUser = state.users[state.currentUser];

    if (!currentUser) {
        showToast('Nenhum usuário logado.', 'error');
        return;
    }

    if (amount <= 0) {
        showToast('O valor do empréstimo deve ser positivo.', 'error');
        return;
    }
    
    transaction((draft) => {
        const draftUser = draft.users[draft.currentUser];
        const installmentValue = (amount * (1 + LOAN_INTEREST_RATE)) / 12; // 12 parcelas mensais
        
        const loan = {
            id: uid(),
            principal: amount,
            remaining: amount * (1 + LOAN_INTEREST_RATE),
            installmentValue,
            periodSec: 60,
            lastChargeAt: now(),
            status: 'pending',
            userId: draftUser.username // Para o ADM identificar
        };
        
        draftUser.loans.push(loan);
        
        addHistoryEntry(draft, draft.currentUser, {
            ts: now(),
            type: 'loan-request',
            amount,
            before: draftUser.balances.checking,
            after: draftUser.balances.checking,
            details: `Solicitação de empréstimo de ${formatMoney(amount)}.`
        });
        showToast('Solicitação de empréstimo enviada para o administrador.', 'info');
    });
}
