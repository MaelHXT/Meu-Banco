 import { getState, transaction } from '../core/store.js';
import { showToast } from './notifications.js';
import { now } from '../core/time.js';
import { addHistoryEntry } from './history.js';
import { uid } from '../core/crypto.js';
import { formatMoney } from '../ui/formatters.js';

const ADMIN_USERNAME = 'cs304352';
const FUNDO_IP_RATE = 0.10 / 365 / 24 / 60 / 60 * 10; // Taxa proporcional a cada 10s

export function processInvestmentDividends(state) {
    const currentTime = now();
    const adminUser = state.users[ADMIN_USERNAME];

    if (!adminUser) return;

    Object.values(state.users).forEach(user => {
        user.investments.forEach(investment => {
            if (currentTime - investment.lastDividendAt >= 10000) {
                let dividendAmount = 0;
                
                if (investment.name === 'Fundo IP') {
                    dividendAmount = investment.principal * FUNDO_IP_RATE;
                } else if (investment.name === 'Cripto Index') {
                    const priceChange = state.cryptoMarket.price - state.cryptoMarket.lastUpdatePrice;
                    dividendAmount = investment.principal * (priceChange / state.cryptoMarket.lastUpdatePrice);
                }

                if (dividendAmount > 0) {
                    user.balances.checking += dividendAmount;
                    adminUser.balances.checking -= dividendAmount;

                    addHistoryEntry(state, user.username, {
                        ts: currentTime,
                        type: 'investment-dividend',
                        amount: dividendAmount,
                        before: user.balances.checking - dividendAmount,
                        after: user.balances.checking,
                        details: `Rendimento de ${formatMoney(dividendAmount)} do investimento '${investment.name}'.`
                    });
                    
                    addHistoryEntry(state, ADMIN_USERNAME, {
                        ts: currentTime,
                        type: 'dividend-paid',
                        amount: -dividendAmount,
                        before: adminUser.balances.checking + dividendAmount,
                        after: adminUser.balances.checking,
                        details: `Pagamento de rendimento de investimento para ${user.username}.`
                    });
                    
                    showToast(`Rendimento de ${formatMoney(dividendAmount)} creditado na sua conta.`, 'success');
                }
                investment.lastDividendAt = currentTime;
            }
        });
    });
}

export function investInFund(amount) {
    const state = getState();
    const currentUser = state.users[state.currentUser];

    if (!currentUser || currentUser.balances.checking < amount) {
        showToast('Saldo insuficiente para investir.', 'error');
        return;
    }

    transaction((draft) => {
        const draftUser = draft.users[draft.currentUser];
        draftUser.balances.checking -= amount;

        const investment = {
            id: uid(),
            name: 'Fundo IP',
            principal: amount,
            createdAt: now(),
            lastDividendAt: now()
        };

        draftUser.investments.push(investment);

        addHistoryEntry(draft, draft.currentUser, {
            ts: now(),
            type: 'investment-buy',
            amount: -amount,
            before: draftUser.balances.checking + amount,
            after: draftUser.balances.checking,
            details: `Compra de cotas no Fundo IP.`
        });
        showToast(`Investimento de ${formatMoney(amount)} no Fundo IP realizado.`, 'success');
    });
}
