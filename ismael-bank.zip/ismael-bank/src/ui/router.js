 import { getState, subscribe } from '../core/store.js';
import { renderLoginScreen } from './screens/login.js';
import { renderAdminDashboard } from './screens/adminDashboard.js';
import { renderClientDashboard } from './screens/clientDashboard.js';

const appContainer = document.getElementById('appContainer');

export function startRouter() {
    const state = getState();
    const currentUser = state.users[state.currentUser];

    if (!currentUser) {
        renderLoginScreen();
    } else {
        if (currentUser.role === 'admin') {
            renderAdminDashboard();
        } else {
            renderClientDashboard();
        }
    }
}

export function renderScreen(html) {
    appContainer.innerHTML = html;
}

// Assina o estado para rotear automaticamente em caso de login/logout
subscribe((state, prevState) => {
    if (state.currentUser !== prevState.currentUser) {
        startRouter();
    }
});
