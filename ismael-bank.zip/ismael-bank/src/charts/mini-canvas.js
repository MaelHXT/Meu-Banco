 import { getState, subscribe } from '../core/store.js';

let priceHistory = [];
let maxPoints = 50;

function updatePriceHistory(state) {
    priceHistory.push(state.cryptoMarket.price);
    if (priceHistory.length > maxPoints) {
        priceHistory.shift();
    }
}

export function renderMiniCanvas() {
    const canvas = document.getElementById('cryptoChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const state = getState();
    updatePriceHistory(state);

    const { width, height } = canvas;
    const padding = 10;
    
    ctx.clearRect(0, 0, width, height);

    if (priceHistory.length < 2) return;

    const prices = priceHistory;
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);

    const range = maxPrice - minPrice;
    const scaleY = (height - 2 * padding) / range;
    const scaleX = (width - 2 * padding) / (prices.length - 1);

    ctx.beginPath();
    ctx.strokeStyle = '#4CAF50';
    ctx.lineWidth = 2;

    const startY = height - padding - (prices[0] - minPrice) * scaleY;
    ctx.moveTo(padding, startY);

    for (let i = 1; i < prices.length; i++) {
        const x = padding + i * scaleX;
        const y = height - padding - (prices[i] - minPrice) * scaleY;
        ctx.lineTo(x, y);
    }

    ctx.stroke();
}

// Assina o estado para redesenhar o gráfico
subscribe(() => renderMiniCanvas());
