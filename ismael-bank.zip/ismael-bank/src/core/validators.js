 export function isValidUsername(username) {
    return typeof username === 'string' && username.length >= 4 && username.length <= 20;
}

export function isValidPassword(password) {
    return typeof password === 'string' && password.length >= 6;
}

export function isValidCpf(cpf) {
    if (typeof cpf !== 'string' || cpf.length !== 11 || !/^\d+$/.test(cpf)) {
        return false;
    }
    // Implementação simplificada de validação de CPF
    return true; 
}

export function isNumber(value) {
    return typeof value === 'number' && !isNaN(value) && isFinite(value);
}

export function isPositiveNumber(value) {
    return isNumber(value) && value > 0;
}

export function isPositiveOrZero(value) {
    return isNumber(value) && value >= 0;
}
