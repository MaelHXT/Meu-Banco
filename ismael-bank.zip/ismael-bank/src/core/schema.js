 export const initialAppState = {
  users: {},
  adminAccountNumber: "47987192856",
  adminUsername: "cs304352",
  companies: [],
  cryptoMarket: {
    price: 100.00,
    lastUpdate: 0
  },
  timers: {
    lastMinuteTick: 0,
    lastDividendTick: 0,
    lastCryptoTick: 0,
    engineLeader: { tabId: null, since: 0 }
  },
  meta: {
    version: 1,
    createdAt: 0,
    updatedAt: 0
  }
};
