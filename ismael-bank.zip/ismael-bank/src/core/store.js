 import { saveState } from "./db.js";
import { showToast } from "../features/notifications.js";
import { initialAppState } from "./schema.js";

let state = { ...initialAppState, currentUser: null };
const subscribers = [];

export function getState() {
    return JSON.parse(JSON.stringify(state)); // Retorna uma cópia para evitar mutações diretas
}

export function setState(nextState, meta = {}) {
    const prevState = state;
    state = nextState;
    saveState(state);
    
    subscribers.forEach(listener => listener(state, prevState, meta));
}

export function subscribe(listener) {
    subscribers.push(listener);
}

export function transaction(mutatorFn) {
    try {
        const draft = JSON.parse(JSON.stringify(state)); // Cria um rascunho mutável
        const result = mutatorFn(draft);
        draft.meta.version += 1;
        draft.meta.updatedAt = Date.now();
        setState(draft, 'transaction');
        return result;
    } catch (e) {
        showToast(`Transação falhou: ${e.message}`, 'error');
        console.error('Transaction failed:', e);
        throw e;
    }
}
