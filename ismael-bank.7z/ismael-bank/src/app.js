 import { startRouter } from './ui/router.js';
import { loadState, initStorage, exportBackup } from './core/db.js';
import { startSync } from './core/sync.js';
import { startEngine } from './core/engine.js';
import { logout } from './features/auth.js';
import { initNotifications } from './features/notifications.js';
import { getState, subscribe } from './core/store.js';
import { formatMoney } from './ui/formatters.js';

async function bootstrap() {
    initNotifications();

    const tabId = crypto.randomUUID();
    console.log(`Iniciando Ismael Bank na aba: ${tabId}`);

    await initStorage();
    await loadState();

    await startSync(tabId);
    
    // Inicia o motor do PWA em um web worker para não travar a UI
    const worker = new Worker('/workers/engine-worker.js');
    worker.postMessage({ type: 'START_ENGINE' });
    
    // Escuta mensagens do worker para atualizar a UI
    worker.onmessage = (event) => {
        if (event.data.type === 'STATE_UPDATE') {
            const newState = event.data.state;
            const currentState = getState();
            if (newState.meta.version > currentState.meta.version) {
                // Atualiza o estado localmente sem salvar, pois o worker já salvou
                Object.assign(currentState, newState);
                subscribe(newState, currentState, 'worker-sync'); // Notifica os subscribers
            }
        }
    };

    startRouter();

    document.getElementById('logoutBtn').addEventListener('click', () => {
        logout();
        startRouter();
    });

    document.getElementById('exportBtn').addEventListener('click', exportBackup);

    // Atualiza a UI quando o estado muda
    subscribe((state) => {
        const currentUser = state.users[state.currentUser];
        const userInfoEl = document.getElementById('userInfo');
        const accountNumberEl = document.getElementById('accountNumberDisplay');
        const logoutBtn = document.getElementById('logoutBtn');
        const exportBtn = document.getElementById('exportBtn');

        if (currentUser) {
            userInfoEl.innerHTML = `Olá, ${currentUser.name}! <br>Saldo: ${formatMoney(currentUser.balances.checking)}`;
            accountNumberEl.textContent = `Conta: ${currentUser.accountNumber}`;
            accountNumberEl.style.display = 'inline';
            logoutBtn.style.display = 'inline';
            exportBtn.style.display = 'inline';
        } else {
            userInfoEl.textContent = '';
            accountNumberEl.style.display = 'none';
            logoutBtn.style.display = 'none';
            exportBtn.style.display = 'none';
        }
    });
}

window.addEventListener('load', bootstrap);
