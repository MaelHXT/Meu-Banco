 import { getState, transaction } from '../core/store.js';
import { showToast } from './notifications.js';
import { addHistoryEntry } from './history.js';
import { now } from '../core/time.js';

export function approveLoan(loanId, username) {
    transaction((draft) => {
        const user = draft.users[username];
        if (!user) {
            showToast('Usuário não encontrado.', 'error');
            return;
        }

        const loan = user.loans.find(l => l.id === loanId);
        if (!loan || loan.status !== 'pending') {
            showToast('Empréstimo inválido ou já aprovado.', 'error');
            return;
        }

        const admin = draft.users[draft.adminUsername];
        if (admin.balances.checking < loan.principal) {
            showToast('Saldo do ADM insuficiente para aprovar o empréstimo.', 'error');
            return;
        }

        loan.status = 'active';
        loan.lastChargeAt = now();
        user.balances.checking += loan.principal;
        admin.balances.checking -= loan.principal;

        addHistoryEntry(draft, username, {
            ts: now(),
            type: 'loan-approved',
            amount: loan.principal,
            before: user.balances.checking - loan.principal,
            after: user.balances.checking,
            details: `Empréstimo de ${loan.principal} aprovado pelo ADM.`
        });
        
        addHistoryEntry(draft, draft.adminUsername, {
            ts: now(),
            type: 'loan-issued',
            amount: -loan.principal,
            before: admin.balances.checking + loan.principal,
            after: admin.balances.checking,
            details: `Empréstimo de ${loan.principal} concedido a ${username}.`
        });

        showToast(`Empréstimo de ${user.name} aprovado!`, 'success');
    });
}

export function denyLoan(loanId, username) {
    transaction((draft) => {
        const user = draft.users[username];
        const loan = user.loans.find(l => l.id === loanId);
        if (loan) {
            loan.status = 'denied';
            addHistoryEntry(draft, username, {
                ts: now(),
                type: 'loan-denied',
                amount: 0,
                before: user.balances.checking,
                after: user.balances.checking,
                details: `Empréstimo de ${loan.principal} negado pelo ADM.`
            });
            showToast(`Empréstimo de ${user.name} negado.`, 'info');
        }
    });
}

export function createClient(name, cpf, username, initialBalance, creditLimit) {
    transaction((draft) => {
        if (draft.users[username]) {
            showToast('Nome de usuário já existe.', 'error');
            return;
        }

        const newAccountNumber = Math.floor(10000000000 + Math.random() * 90000000000).toString();
        const newUser = {
            id: uid(),
            role: 'client',
            name,
            cpf,
            accountNumber: newAccountNumber,
            balances: {
                checking: initialBalance,
                creditLimit: creditLimit,
                creditUsed: 0
            },
            investments: [],
            loans: [],
            creditInvoices: [],
            crypto: {
                balance: 0,
                lastTradeAt: now()
            },
            history: []
        };
        draft.users[username] = newUser;
        addHistoryEntry(draft, username, {
            ts: now(),
            type: 'admin-creation',
            amount: initialBalance,
            before: 0,
            after: initialBalance,
            details: 'Conta criada e saldo inicial definido pelo ADM.'
        });
        showToast(`Cliente ${name} criado com sucesso!`, 'success');
    });
}
