 import { getState, transaction } from '../core/store.js';
import { hashPassword, generateAccountNumber, uid } from '../core/crypto.js';
import { showToast } from './notifications.js';
import { isValidUsername, isValidPassword, isValidCpf, isPositiveOrZero } from '../core/validators.js';
import { now } from '../core/time.js';
import { addHistoryEntry } from './history.js';

export async function login(username, password) {
    const state = getState();
    const user = state.users[username];
    
    if (!user) {
        showToast('Usuário ou senha inválidos.', 'error');
        return false;
    }
    
    const hashedPassword = await hashPassword(password);
    if (user.passwordHash !== hashedPassword) {
        showToast('Usuário ou senha inválidos.', 'error');
        return false;
    }
    
    transaction((draft) => {
        draft.currentUser = username;
    });

    showToast('Login bem-sucedido!', 'success');
    return true;
}

export async function register(name, cpf, username, password) {
    const state = getState();
    
    if (state.users[username]) {
        showToast('Nome de usuário já existe.', 'error');
        return false;
    }
    if (!isValidUsername(username) || !isValidPassword(password) || !isValidCpf(cpf)) {
        showToast('Dados de registro inválidos.', 'error');
        return false;
    }
    
    const hashedPassword = await hashPassword(password);
    const newAccountNumber = generateAccountNumber();
    
    const newUser = {
        id: uid(),
        role: 'client',
        name,
        cpf,
        accountNumber: newAccountNumber,
        passwordHash: hashedPassword,
        balances: {
            checking: 500,
            creditLimit: 2000,
            creditUsed: 0
        },
        investments: [],
        loans: [],
        creditInvoices: [],
        crypto: {
            balance: 0,
            lastTradeAt: now()
        },
        history: []
    };
    
    transaction((draft) => {
        draft.users[username] = newUser;
        addHistoryEntry(draft, username, {
            ts: now(),
            type: 'register',
            amount: 500,
            before: 0,
            after: 500,
            details: 'Abertura de conta e saldo inicial.'
        });
        draft.currentUser = username;
    });

    showToast('Registro realizado com sucesso!', 'success');
    return true;
}

export function logout() {
    transaction((draft) => {
        draft.currentUser = null;
    });
    showToast('Sessão encerrada.', 'info');
}
