 import { getState, transaction } from '../core/store.js';
import { showToast } from './notifications.js';
import { now } from '../core/time.js';
import { addHistoryEntry } from './history.js';
import { uid } from '../core/crypto.js';
import { formatMoney } from '../ui/formatters.js';

export function purchaseWithCredit(amount, installments) {
    const state = getState();
    const currentUser = state.users[state.currentUser];

    if (!currentUser) {
        showToast('Nenhum usuário logado.', 'error');
        return;
    }

    if (amount <= 0 || installments <= 0) {
        showToast('Valores inválidos.', 'error');
        return;
    }

    if (currentUser.balances.creditUsed + amount > currentUser.balances.creditLimit) {
        showToast('Limite de crédito insuficiente.', 'error');
        return;
    }
    
    transaction((draft) => {
        const draftUser = draft.users[draft.currentUser];
        
        const invoice = {
            id: uid(),
            total: amount,
            installments,
            installmentValue: amount / installments,
            remainingInstallments: installments,
            lastChargeAt: now()
        };

        draftUser.balances.creditUsed += amount;
        draftUser.creditInvoices.push(invoice);
        
        addHistoryEntry(draft, draft.currentUser, {
            ts: now(),
            type: 'credit-purchase',
            amount,
            before: draftUser.balances.creditUsed - amount,
            after: draftUser.balances.creditUsed,
            details: `Compra de ${formatMoney(amount)} em ${installments} parcelas.`
        });
        showToast(`Compra de ${formatMoney(amount)} no crédito realizada.`, 'success');
    });
}
