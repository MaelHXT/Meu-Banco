 import { getState, transaction } from '../core/store.js';
import { showToast } from './notifications.js';
import { now } from '../core/time.js';
import { addHistoryEntry } from './history.js';
import { formatMoney } from '../ui/formatters.js';

export function pixTransfer(recipientAccountNumber, amount) {
    const state = getState();
    const currentUser = state.users[state.currentUser];

    if (!currentUser) {
        showToast('Nenhum usuário logado.', 'error');
        return;
    }

    if (amount <= 0 || currentUser.balances.checking < amount) {
        showToast('Saldo insuficiente ou valor inválido.', 'error');
        return;
    }

    const recipientUser = Object.values(state.users).find(u => u.accountNumber === recipientAccountNumber);

    if (!recipientUser) {
        showToast('Conta PIX de destino não encontrada.', 'error');
        return;
    }

    transaction((draft) => {
        const sender = draft.users[draft.currentUser];
        const receiver = draft.users[recipientUser.username];

        sender.balances.checking -= amount;
        receiver.balances.checking += amount;

        addHistoryEntry(draft, sender.username, {
            ts: now(),
            type: 'pix-sent',
            amount: -amount,
            before: sender.balances.checking + amount,
            after: sender.balances.checking,
            details: `PIX enviado para ${receiver.name} (${receiver.accountNumber}).`
        });

        addHistoryEntry(draft, receiver.username, {
            ts: now(),
            type: 'pix-received',
            amount,
            before: receiver.balances.checking - amount,
            after: receiver.balances.checking,
            details: `PIX recebido de ${sender.name} (${sender.accountNumber}).`
        });

        showToast(`Transferência PIX de ${formatMoney(amount)} para ${receiver.name} realizada com sucesso!`, 'success');
    });
}
