 export function addHistoryEntry(state, username, entry) {
    const user = state.users[username];
    if (user) {
        user.history.unshift(entry);
    }
}
