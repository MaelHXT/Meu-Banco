 import { showToast } from "../features/notifications.js";
import { initialAppState } from "./schema.js";
import { getState, setState } from "./store.js";
import { now } from "./time.js";

const DB_NAME = 'ISMAEL_BANK_DB';
const DB_VERSION = 1;
const STORE_NAME = 'appStateStore';

let db = null;
let opfsRoot = null;
let opfsReady = false;

async function getOPFSFileHandle() {
    if (!opfsReady) {
        try {
            opfsRoot = await navigator.storage.getDirectory();
            opfsReady = true;
        } catch (e) {
            console.warn('OPFS not available, falling back to IndexedDB.', e);
        }
    }
    return opfsReady ? opfsRoot.getFileHandle('db.json', { create: true }) : null;
}

function openIndexedDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME);
            }
        };
        request.onsuccess = (event) => resolve(event.target.result);
        request.onerror = (event) => reject(event.target.error);
    });
}

export async function initStorage() {
    if (!('indexedDB' in window)) {
        showToast('Navegador não suporta IndexedDB ou OPFS. Persistência de dados será limitada.', 'warning');
    }
}

export async function loadState() {
    let state = null;
    try {
        const fileHandle = await getOPFSFileHandle();
        if (fileHandle) {
            const file = await fileHandle.getFile();
            const text = await file.text();
            state = text ? JSON.parse(text) : null;
            if (state) {
                console.log('Estado carregado do OPFS.');
            }
        }
    } catch (e) {
        console.warn('Falha ao carregar do OPFS.', e);
    }

    if (!state) {
        try {
            db = await openIndexedDB();
            const tx = db.transaction(STORE_NAME, 'readonly');
            const store = tx.objectStore(STORE_NAME);
            const request = store.get(STORE_NAME);
            state = await new Promise((resolve) => {
                request.onsuccess = (event) => resolve(event.target.result);
                request.onerror = () => resolve(null);
            });
            if (state) {
                console.log('Estado carregado do IndexedDB.');
            }
        } catch (e) {
            console.warn('Falha ao carregar do IndexedDB.', e);
        }
    }

    if (!state) {
        console.log('Nenhum estado encontrado. Carregando seeds.');
        try {
            const response = await fetch('/data/seed.json');
            state = await response.json();
            
            // Adiciona o ADM inicial
            const adminUser = {
                id: 'admin_id',
                role: 'admin',
                name: 'Ismael Pacheco',
                cpf: '00000000000',
                accountNumber: state.adminAccountNumber,
                passwordHash: await hashPassword("140819"),
                balances: { checking: 90000000000, creditLimit: 0, creditUsed: 0 },
                investments: [],
                loans: [],
                creditInvoices: [],
                crypto: { balance: 0, lastTradeAt: now() },
                history: []
            };
            state.users[state.adminUsername] = adminUser;

        } catch (e) {
            console.error('Falha ao carregar seed.json. Usando estado inicial.', e);
            state = initialAppState;
        }
    }

    if (state.meta.createdAt === 0) {
        state.meta.createdAt = now();
        state.meta.updatedAt = now();
    }
    
    setState(state, 'load');
}

export async function saveState(state) {
    if (!state) return;
    
    // Tentativa de lock para atomicidade
    const lock = 'locks' in navigator ? await navigator.locks.request('db-lock', { mode: 'exclusive' }) : null;

    try {
        const stateToSave = { ...state, meta: { ...state.meta, updatedAt: now() } };
        const serializedState = JSON.stringify(stateToSave);

        const fileHandle = await getOPFSFileHandle();
        if (fileHandle) {
            const writable = await fileHandle.createWritable();
            await writable.write(serializedState);
            await writable.close();
            console.log('Estado salvo no OPFS.');
        } else if (db) {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            const store = tx.objectStore(STORE_NAME);
            store.put(stateToSave, STORE_NAME);
            await new Promise((resolve) => { tx.oncomplete = resolve; });
            console.log('Estado salvo no IndexedDB.');
        }

        // Espelha no localStorage para recuperação rápida e sincronização
        localStorage.setItem('db_snapshot', serializedState);

    } catch (e) {
        console.error('Falha ao salvar o estado:', e);
        showToast('Falha ao salvar o estado do banco. Verifique as permissões.', 'error');
    } finally {
        if (lock) lock.release();
    }
}

export async function exportBackup() {
    const state = getState();
    const date = new Date().toISOString().replace(/T/, '_').replace(/:/g, '-').split('.')[0];
    const fileName = `ISMAEL_BANK_BACKUP_${date}.json`;
    const data = JSON.stringify(state, null, 2);

    try {
        const opfsRoot = await navigator.storage.getDirectory();
        const backupsDir = await opfsRoot.getDirectoryHandle('backups', { create: true });
        const fileHandle = await backupsDir.getFileHandle(fileName, { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write(data);
        await writable.close();
        showToast('Backup exportado para a pasta /data/backups', 'success');
    } catch (e) {
        console.error('Falha ao exportar backup para OPFS.', e);
        showToast('Falha ao exportar backup. Tente salvar manualmente.', 'error');
    }

    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

export async function importBackup(file) {
    if (!file) {
        showToast('Nenhum arquivo selecionado.', 'error');
        return;
    }
    try {
        const text = await file.text();
        const importedState = JSON.parse(text);
        
        // Validação básica de schema
        if (!importedState.users || !importedState.meta) {
            throw new Error('Formato de arquivo inválido.');
        }
        
        // Substitui o estado atual
        setState(importedState, 'import');
        showToast('Backup importado com sucesso!', 'success');
    } catch (e) {
        showToast(`Falha ao importar backup: ${e.message}`, 'error');
        console.error('Import failed:', e);
    }
}
