 export function now() {
    return Date.now();
}

export function toISO(timestamp) {
    return new Date(timestamp).toISOString();
}

export function formatTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
}
