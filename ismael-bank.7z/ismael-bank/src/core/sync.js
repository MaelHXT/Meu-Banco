 import { getState, setState, transaction } from './store.js';
import { now } from './time.js';

const SYNC_CHANNEL = 'ismael-bank-sync';
const LEADER_KEY = 'leader_election';
const LEADER_TIMEOUT = 5000;
const broadcastChannel = new BroadcastChannel(SYNC_CHANNEL);

let tabId = null;

export async function startSync(currentTabId) {
    tabId = currentTabId;

    await electionLeader();

    broadcastChannel.onmessage = (event) => {
        const { type, payload } = event.data;
        if (type === 'STATE_PATCH') {
            const currentState = getState();
            if (payload.meta.version > currentState.meta.version) {
                transaction(() => {
                    setState(payload, 'sync');
                });
            }
        }
    };

    window.addEventListener('storage', (event) => {
        if (event.key === 'db_snapshot' && event.newValue) {
            const remoteState = JSON.parse(event.newValue);
            const currentState = getState();
            if (remoteState.meta.version > currentState.meta.version) {
                transaction(() => {
                    setState(remoteState, 'storage');
                });
            }
        }
    });

    setInterval(electionLeader, LEADER_TIMEOUT / 2);
}

export async function electionLeader() {
    const leaderInfo = JSON.parse(localStorage.getItem(LEADER_KEY) || '{}');
    const currentTime = now();

    if (!leaderInfo.tabId || (currentTime - leaderInfo.lastSeen > LEADER_TIMEOUT)) {
        const newLeaderInfo = { tabId, lastSeen: currentTime };
        localStorage.setItem(LEADER_KEY, JSON.stringify(newLeaderInfo));
        
        await transaction((state) => {
            state.timers.engineLeader = { tabId, since: now() };
        });
        console.log(`Nova aba líder eleita: ${tabId}`);
    }

    const currentLeader = JSON.parse(localStorage.getItem(LEADER_KEY));
    if (currentLeader.tabId === tabId) {
        currentLeader.lastSeen = now();
        localStorage.setItem(LEADER_KEY, JSON.stringify(currentLeader));
    }
}

export function getLeaderTabId() {
    const leaderInfo = JSON.parse(localStorage.getItem(LEADER_KEY) || '{}');
    return leaderInfo.tabId;
}

export function dispatchStatePatch(newState) {
    broadcastChannel.postMessage({ type: 'STATE_PATCH', payload: newState });
}
