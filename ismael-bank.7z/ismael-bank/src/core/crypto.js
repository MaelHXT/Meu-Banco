 export async function hashPassword(password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex;
}

export function generateAccountNumber() {
    return Math.floor(10000000000 + Math.random() * 90000000000).toString();
}

export function uid() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}
