 import { getState, transaction } from './store.js';
import { now } from './time.js';
import { dispatchStatePatch, getLeaderTabId } from './sync.js';
import { processCompanyDeposits, processCreditCharges, processLoanCharges } from '../features/accounts.js';
import { processInvestmentDividends } from '../features/investments.js';
import { updateCryptoPrice } from '../features/crypto-market.js';
import { showToast } from '../features/notifications.js';

let isRunning = false;

export function startEngine() {
    if (isRunning) return;
    isRunning = true;
    
    function runLoop() {
        const state = getState();
        const currentTime = now();
        let hasChanged = false;

        if (state.timers.engineLeader.tabId !== getLeaderTabId()) {
            isRunning = false;
            console.log('Não sou mais a aba líder. Parando o motor.');
            return;
        }

        // Tick a cada 60 segundos
        if (currentTime - state.timers.lastMinuteTick >= 60000) {
            console.log('Executando tick de 60s...');
            transaction((draft) => {
                processCompanyDeposits(draft);
                processCreditCharges(draft);
                processLoanCharges(draft);
                draft.timers.lastMinuteTick = currentTime;
            });
            hasChanged = true;
        }

        // Tick a cada 10 segundos
        if (currentTime - state.timers.lastDividendTick >= 10000) {
            console.log('Executando tick de 10s...');
            transaction((draft) => {
                processInvestmentDividends(draft);
                draft.timers.lastDividendTick = currentTime;
            });
            hasChanged = true;
        }

        // Tick a cada 5 segundos
        if (currentTime - state.timers.lastCryptoTick >= 5000) {
            console.log('Executando tick de 5s...');
            transaction((draft) => {
                updateCryptoPrice(draft);
                draft.timers.lastCryptoTick = currentTime;
            });
            hasChanged = true;
        }

        if (hasChanged) {
            dispatchStatePatch(getState());
        }

        setTimeout(runLoop, 1000); // Roda a cada segundo
    }
    
    console.log('Motor da aplicação iniciado.');
    runLoop();
}
