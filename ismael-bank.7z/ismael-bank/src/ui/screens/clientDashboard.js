 import { getState, subscribe } from '../../core/store.js';
import { renderScreen } from '../router.js';
import { formatMoney, formatDateTime } from '../formatters.js';
import { purchaseWithCredit } from '../../features/credit.js';
import { requestLoan } from '../../features/loans.js';
import { buyCrypto, sellCrypto } from '../../features/crypto-market.js';
import { investInFund } from '../../features/investments.js';
import { pixTransfer } from '../../features/pix.js';
import { withdraw, deposit } from '../../features/accounts.js';
import { renderMiniCanvas } from '../../charts/mini-canvas.js';

export function renderClientDashboard() {
    const state = getState();
    const user = state.users[state.currentUser];
    const cryptoPrice = state.cryptoMarket.price;
    const historyList = user.history.slice(0, 10);

    const html = `
        <div class="dashboard-container">
            <h1>Dashboard do Cliente</h1>
            <div class="user-summary">
                <div class="summary-item">
                    <span>Saldo em Conta</span>
                    <span class="value-large">${formatMoney(user.balances.checking)}</span>
                </div>
                <div class="summary-item">
                    <span>Limite de Crédito</span>
                    <span class="value-large">${formatMoney(user.balances.creditLimit)}</span>
                    <span class="value-small">Utilizado: ${formatMoney(user.balances.creditUsed)}</span>
                </div>
                <div class="summary-item">
                    <span>Saldo em ISB</span>
                    <span class="value-large">${user.crypto.balance.toFixed(4)} ISB</span>
                    <span class="value-small">Preço atual: ${formatMoney(cryptoPrice)}</span>
                </div>
            </div>
            
            <div class="card section-card">
                <h2>Cotação ISB (5s)</h2>
                <canvas id="cryptoChart" width="100%" height="80"></canvas>
            </div>

            <div class="actions-grid">
                <div class="card action-card">
                    <h3>Movimentações</h3>
                    <input type="number" id="pixAmount" placeholder="Valor PIX" min="1">
                    <input type="text" id="pixRecipient" placeholder="Conta de Destino" required>
                    <button class="btn btn-primary" id="pixBtn">Enviar PIX</button>
                    <hr>
                    <input type="number" id="depositAmount" placeholder="Valor Depósito" min="1">
                    <button class="btn btn-primary" id="depositBtn">Depositar</button>
                    <hr>
                    <input type="number" id="withdrawAmount" placeholder="Valor Saque" min="1">
                    <button class="btn btn-primary" id="withdrawBtn">Sacar</button>
                </div>
                
                <div class="card action-card">
                    <h3>Compras e Empréstimos</h3>
                    <input type="number" id="creditAmount" placeholder="Valor compra" min="1">
                    <input type="number" id="creditInstallments" placeholder="Parcelas" min="1" max="12">
                    <button class="btn btn-primary" id="creditBtn">Comprar no Crédito</button>
                    <hr>
                    <input type="number" id="loanAmount" placeholder="Valor empréstimo" min="1">
                    <button class="btn btn-primary" id="loanBtn">Solicitar Empréstimo</button>
                </div>
                
                <div class="card action-card">
                    <h3>Investimentos</h3>
                    <input type="number" id="fundAmount" placeholder="Valor Fundo IP" min="1">
                    <button class="btn btn-primary" id="fundBtn">Investir</button>
                    <hr>
                    <input type="number" id="cryptoBuyAmount" placeholder="Quantidade ISB" min="0.0001">
                    <button class="btn btn-primary" id="cryptoBuyBtn">Comprar ISB</button>
                    <hr>
                    <input type="number" id="cryptoSellAmount" placeholder="Quantidade ISB" min="0.0001">
                    <button class="btn btn-primary" id="cryptoSellBtn">Vender ISB</button>
                </div>
            </div>
            
            <div class="card section-card">
                <h2>Seus Empréstimos e Faturas</h2>
                <div id="loansList">
                    ${user.loans.map(l => `
                        <div class="list-item">
                            <span>Empréstimo de ${formatMoney(l.principal)} - ${l.status}</span>
                            <span>Faltam: ${formatMoney(l.remaining)}</span>
                        </div>
                    `).join('')}
                </div>
                <div id="invoicesList">
                    ${user.creditInvoices.map(inv => `
                        <div class="list-item">
                            <span>Fatura de ${formatMoney(inv.total)} - ${inv.remainingInstallments} parcelas</span>
                            <span>Valor da parcela: ${formatMoney(inv.installmentValue)}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div class="card section-card">
                <h2>Seu Histórico (últimos 10)</h2>
                <div id="historyList">
                    ${historyList.map(h => `
                        <div class="list-item">
                            <span>${formatDateTime(h.ts)} - ${h.details}</span>
                            <span>${h.amount >= 0 ? '+' : ''}${formatMoney(h.amount)}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;

    renderScreen(html);
    renderMiniCanvas();

    document.getElementById('pixBtn').addEventListener('click', () => {
        const amount = parseFloat(document.getElementById('pixAmount').value);
        const recipient = document.getElementById('pixRecipient').value;
        pixTransfer(recipient, amount);
    });
    document.getElementById('depositBtn').addEventListener('click', () => {
        const amount = parseFloat(document.getElementById('depositAmount').value);
        deposit(amount, user.username);
    });
    document.getElementById('withdrawBtn').addEventListener('click', () => {
        const amount = parseFloat(document.getElementById('withdrawAmount').value);
        withdraw(amount, user.username);
    });
    document.getElementById('creditBtn').addEventListener('click', () => {
        const amount = parseFloat(document.getElementById('creditAmount').value);
        const installments = parseInt(document.getElementById('creditInstallments').value);
        purchaseWithCredit(amount, installments);
    });
    document.getElementById('loanBtn').addEventListener('click', () => {
        const amount = parseFloat(document.getElementById('loanAmount').value);
        requestLoan(amount);
    });
    document.getElementById('fundBtn').addEventListener('click', () => {
        const amount = parseFloat(document.getElementById('fundAmount').value);
        investInFund(amount);
    });
    document.getElementById('cryptoBuyBtn').addEventListener('click', () => {
        const amount = parseFloat(document.getElementById('cryptoBuyAmount').value);
        buyCrypto(amount);
    });
    document.getElementById('cryptoSellBtn').addEventListener('click', () => {
        const amount = parseFloat(document.getElementById('cryptoSellAmount').value);
        sellCrypto(amount);
    });

    subscribe((newState) => {
        const updatedUser = newState.users[newState.currentUser];
        if (updatedUser) {
            document.querySelector('.user-summary .value-large').textContent = formatMoney(updatedUser.balances.checking);
            document.querySelector('.summary-item:nth-child(2) .value-large').textContent = formatMoney(updatedUser.balances.creditLimit);
            document.querySelector('.summary-item:nth-child(2) .value-small').textContent = `Utilizado: ${formatMoney(updatedUser.balances.creditUsed)}`;
            document.querySelector('.summary-item:nth-child(3) .value-large').textContent = `${updatedUser.crypto.balance.toFixed(4)} ISB`;
            document.querySelector('.summary-item:nth-child(3) .value-small').textContent = `Preço atual: ${formatMoney(newState.cryptoMarket.price)}`;
        }
        
        const historyEl = document.getElementById('historyList');
        if (historyEl) {
            const historyList = updatedUser.history.slice(0, 10);
            historyEl.innerHTML = historyList.map(h => `
                <div class="list-item">
                    <span>${formatDateTime(h.ts)} - ${h.details}</span>
                    <span>${h.amount >= 0 ? '+' : ''}${formatMoney(h.amount)}</span>
                </div>
            `).join('');
        }
        
        const loansEl = document.getElementById('loansList');
        if (loansEl) {
            loansEl.innerHTML = updatedUser.loans.map(l => `
                <div class="list-item">
                    <span>Empréstimo de ${formatMoney(l.principal)} - ${l.status}</span>
                    <span>Faltam: ${formatMoney(l.remaining)}</span>
                </div>
            `).join('');
        }
        
        const invoicesEl = document.getElementById('invoicesList');
        if (invoicesEl) {
            invoicesEl.innerHTML = updatedUser.creditInvoices.map(inv => `
                <div class="list-item">
                    <span>Fatura de ${formatMoney(inv.total)} - ${inv.remainingInstallments} parcelas</span>
                    <span>Valor da parcela: ${formatMoney(inv.installmentValue)}</span>
                </div>
            `).join('');
        }

        renderMiniCanvas();
    });
}
