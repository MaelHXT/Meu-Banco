 import { login, register } from '../../features/auth.js';
import { renderScreen, startRouter } from '../router.js';
import { showToast } from '../../features/notifications.js';

function getLoginHtml() {
    return `
        <div class="card login-card">
            <h2>Login</h2>
            <form id="loginForm">
                <input type="text" id="loginUsername" placeholder="Usuário" required>
                <input type="password" id="loginPassword" placeholder="Senha" required>
                <button type="submit" class="btn btn-primary">Entrar</button>
            </form>
            <p>Não tem conta? <a href="#" id="showRegister">Cadastre-se</a></p>
        </div>
    `;
}

function getRegisterHtml() {
    return `
        <div class="card login-card">
            <h2>Cadastre-se</h2>
            <form id="registerForm">
                <input type="text" id="registerName" placeholder="Nome Completo" required>
                <input type="text" id="registerCpf" placeholder="CPF" required>
                <input type="text" id="registerUsername" placeholder="Usuário" required>
                <input type="password" id="registerPassword" placeholder="Senha" required>
                <button type="submit" class="btn btn-primary">Registrar</button>
            </form>
            <p>Já tem conta? <a href="#" id="showLogin">Entrar</a></p>
        </div>
    `;
}

export function renderLoginScreen() {
    renderScreen(getLoginHtml());

    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;
        await login(username, password);
    });

    document.getElementById('showRegister').addEventListener('click', (e) => {
        e.preventDefault();
        renderScreen(getRegisterHtml());
        setupRegisterEvents();
    });
}

function setupRegisterEvents() {
    document.getElementById('registerForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('registerName').value;
        const cpf = document.getElementById('registerCpf').value;
        const username = document.getElementById('registerUsername').value;
        const password = document.getElementById('registerPassword').value;

        const success = await register(name, cpf, username, password);
        if (success) {
            renderLoginScreen();
        }
    });

    document.getElementById('showLogin').addEventListener('click', (e) => {
        e.preventDefault();
        renderLoginScreen();
    });
}
