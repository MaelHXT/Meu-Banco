 import { getState, subscribe } from '../../core/store.js';
import { renderScreen } from '../router.js';
import { formatMoney, formatDateTime } from '../formatters.js';
import { approveLoan, denyLoan } from '../../features/admin.js';

export function renderAdminDashboard() {
    const state = getState();
    const admin = state.users[state.adminUsername];
    const clients = Object.values(state.users).filter(u => u.role === 'client');
    const pendingLoans = Object.values(state.users).flatMap(u => u.loans.filter(l => l.status === 'pending')).map(l => ({ ...l, username: l.userId }));
    const allHistory = Object.values(state.users).flatMap(u => u.history);

    const html = `
        <div class="dashboard-container">
            <h1>Dashboard do Administrador</h1>
            <div class="user-summary">
                <div class="summary-item">
                    <span>Saldo Total do Banco</span>
                    <span class="value-large">${formatMoney(admin.balances.checking)}</span>
                </div>
            </div>
            
            <div class="card section-card">
                <h2>Clientes (${clients.length})</h2>
                <div id="usersList">
                    ${clients.map(client => `
                        <div class="list-item">
                            <span>${client.name} (${client.username}) - Conta: ${client.accountNumber}</span>
                            <span>Saldo: ${formatMoney(client.balances.checking)}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div class="card section-card">
                <h2>Empréstimos Pendentes (${pendingLoans.length})</h2>
                <div id="pendingLoansList">
                    ${pendingLoans.map(loan => `
                        <div class="list-item">
                            <span>${loan.username} - ${formatMoney(loan.principal)}</span>
                            <div>
                                <button class="btn btn-primary" data-id="${loan.id}" data-user="${loan.username}" data-action="approve">Aprovar</button>
                                <button class="btn btn-error" data-id="${loan.id}" data-user="${loan.username}" data-action="deny">Negar</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div class="card section-card">
                <h2>Histórico Geral</h2>
                <div id="historyList">
                    ${allHistory.map(h => `
                        <div class="list-item">
                            <span>${formatDateTime(h.ts)} - ${h.details}</span>
                            <span>${formatMoney(h.amount)}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;

    renderScreen(html);

    document.querySelectorAll('#pendingLoansList button').forEach(button => {
        button.addEventListener('click', (e) => {
            const { id, user, action } = e.target.dataset;
            if (action === 'approve') {
                approveLoan(id, user);
            } else if (action === 'deny') {
                denyLoan(id, user);
            }
        });
    });

    // Atualiza a UI em tempo real
    subscribe(() => {
        const newState = getState();
        const newAdmin = newState.users[newState.adminUsername];
        if (newAdmin) {
            document.querySelector('.user-summary .value-large').textContent = formatMoney(newAdmin.balances.checking);
        }
        
        const newClients = Object.values(newState.users).filter(u => u.role === 'client');
        document.getElementById('usersList').innerHTML = newClients.map(client => `
            <div class="list-item">
                <span>${client.name} (${client.username}) - Conta: ${client.accountNumber}</span>
                <span>Saldo: ${formatMoney(client.balances.checking)}</span>
            </div>
        `).join('');

        const newPendingLoans = Object.values(newState.users).flatMap(u => u.loans.filter(l => l.status === 'pending')).map(l => ({ ...l, username: l.userId }));
        document.getElementById('pendingLoansList').innerHTML = newPendingLoans.map(loan => `
            <div class="list-item">
                <span>${loan.username} - ${formatMoney(loan.principal)}</span>
                <div>
                    <button class="btn btn-primary" data-id="${loan.id}" data-user="${loan.username}" data-action="approve">Aprovar</button>
                    <button class="btn btn-error" data-id="${loan.id}" data-user="${loan.username}" data-action="deny">Negar</button>
                </div>
            </div>
        `).join('');

        document.querySelectorAll('#pendingLoansList button').forEach(button => {
            button.addEventListener('click', (e) => {
                const { id, user, action } = e.target.dataset;
                if (action === 'approve') {
                    approveLoan(id, user);
                } else if (action === 'deny') {
                    denyLoan(id, user);
                }
            });
        });
        
        const newAllHistory = Object.values(newState.users).flatMap(u => u.history);
        document.getElementById('historyList').innerHTML = newAllHistory.map(h => `
            <div class="list-item">
                <span>${formatDateTime(h.ts)} - ${h.details}</span>
                <span>${formatMoney(h.amount)}</span>
            </div>
        `).join('');
    });
}
