 export function formatMoney(amount) {
    if (isNaN(amount) || amount === null) return 'R$ 0,00';
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(amount);
}

export function formatDateTime(timestamp) {
    const date = new Date(timestamp);
    const options = {
        year: 'numeric', month: 'numeric', day: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    };
    return date.toLocaleString('pt-BR', options);
}
