 // Este arquivo pode conter funções para gerar componentes reutilizáveis.
// Por exemplo:
// export function createCard(title, content) { ... }
// export function createModal(content) { ... }
// Para este projeto, o código HTML está embutido nas telas.
